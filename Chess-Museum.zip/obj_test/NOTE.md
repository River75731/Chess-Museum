v       顶点
vn      顶点法线
vt      贴图坐标点
g       组名称
s       光滑组
o       对象名称
f       面
usemtl  指定材质