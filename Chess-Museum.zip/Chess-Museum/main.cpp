#include "View/View.h"

int main(int argc, char* argv[])
{
	View::Init(argc, argv);
	return 0;
}
