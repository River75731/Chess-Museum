#include "ViewScene.h"

int ViewScene::sceneCount = 0;