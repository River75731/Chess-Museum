#include "ViewGroup.h"

int ViewGroup::groupCount = 0;